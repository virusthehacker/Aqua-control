# AquaControl Pro X Android WebView project

## Project files
- `settings.gradle`, root `build.gradle`, `gradle.properties`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/aquacontrol/prox/MainActivity.java`
- `app/src/main/assets/index.html` (dashboard and Firebase Settings UI)
- `.github/workflows/build-apk.yml` (cloud APK build)

## AndroidIDE
1. Extract this ZIP into a folder.
2. Open the folder that directly contains `settings.gradle`, `build.gradle`, and `app/`.
3. This project uses Android Gradle Plugin 8.7.3 and requires Gradle 8.9+ and JDK 17. The Gradle 6.1.1 shown in some AndroidIDE terminals is too old for this project. If AndroidIDE cannot configure a compatible Gradle/JDK, use the included GitHub Actions workflow to build it.
4. If a compatible Gradle is available, from this folder run `gradle assembleDebug`.
5. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions build using your phone
1. Upload all files in this project folder to the root of a GitHub repository (do not upload an extra enclosing folder).
2. Open the repository's Actions tab, select `Build AquaControl Pro X APK`, then choose Run workflow.
3. Open the completed run and download artifact `AquaControlProX-debug-apk`.

## Firebase setup
In the app's Firebase Settings, enter the exact Realtime Database URL, Web API Key, Project ID, and App ID from Firebase Console. Select anonymous authentication and enable Anonymous in Firebase Authentication. Configure secure Realtime Database rules before use. The example URL is only a placeholder. The app's Firebase configuration does not replace local ESP32 pump safety interlocks.
